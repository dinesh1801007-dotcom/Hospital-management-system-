const mongoose = require("mongoose");
const schema = new mongoose.Schema({
  patientName: { type: String, required: true, trim: true },
  doctorName: { type: String, required: true, trim: true },
  date: { type: String, required: true },
  time: { type: String, required: true },
  reason: { type: String, default: "" },
  status: { type: String, enum: ["Scheduled", "Completed", "Cancelled"], default: "Scheduled" },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model("Appointment", schema);
