const mongoose = require("mongoose");
const schema = new mongoose.Schema({
  patientName: { type: String, required: true, trim: true },
  description: { type: String, required: true, trim: true },
  amount: { type: Number, required: true, min: 0 },
  status: { type: String, enum: ["Unpaid", "Paid"], default: "Unpaid" },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model("Bill", schema);
