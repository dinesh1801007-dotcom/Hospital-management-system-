const mongoose = require("mongoose");
const schema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  specialization: { type: String, required: true, trim: true },
  phone: { type: String, required: true, trim: true },
  schedule: { type: String, default: "Mon-Fri, 9:00 AM - 5:00 PM" }
});
module.exports = mongoose.model("Doctor", schema);
