const state = { patients: [], doctors: [], appointments: [], bills: [] };
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
let toastTimer;

function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 3000);
}
function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}
function money(value) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(Number(value) || 0);
}
function formatDate(value) {
  if (!value) return "—";
  const d = new Date(`${value}T00:00:00`);
  return Number.isNaN(d.getTime()) ? escapeHtml(value) : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
async function api(path, options = {}) {
  const response = await fetch(`/api/${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Request failed");
  return data;
}
function showView(view) {
  $$(".view").forEach((el) => el.classList.toggle("hidden", el.id !== `${view}-view`));
  $$(".nav-link").forEach((el) => el.classList.toggle("active", el.dataset.view === view));
  const titles = { dashboard: "Dashboard", patients: "Patients", doctors: "Doctors", appointments: "Appointments", billing: "Billing" };
  $("#page-title").textContent = titles[view] || "Dashboard";
  if (view !== "dashboard") loadSection(view);
}
function showForm(name) {
  const form = $(`#${name}-form`);
  form.classList.toggle("hidden");
  if (!form.classList.contains("hidden")) form.scrollIntoView({ behavior: "smooth", block: "center" });
}
function bindSearch(inputId, render) {
  $(inputId).addEventListener("input", render);
}
function matches(query, values) {
  const q = query.trim().toLowerCase();
  return !q || values.some((v) => String(v ?? "").toLowerCase().includes(q));
}
function renderPatients() {
  const rows = state.patients.filter(p => matches($("#patient-search").value, [p.name,p.phone,p.email,p.gender]));
  $("#patients-table").innerHTML = rows.length ? rows.map(p => `<tr><td><strong>${escapeHtml(p.name)}</strong></td><td>${escapeHtml(p.age)}</td><td>${escapeHtml(p.gender)}</td><td>${escapeHtml(p.phone)}</td><td>${escapeHtml(p.email || "—")}</td><td><button class="table-action danger" data-delete="patients" data-id="${p._id}">Delete</button></td></tr>`).join("") : '<tr><td colspan="6" class="empty">No matching patient records.</td></tr>';
}
function renderDoctors() {
  const rows = state.doctors.filter(d => matches($("#doctor-search").value, [d.name,d.specialization,d.phone,d.schedule]));
  $("#doctors-table").innerHTML = rows.length ? rows.map(d => `<tr><td><strong>${escapeHtml(d.name)}</strong></td><td>${escapeHtml(d.specialization)}</td><td>${escapeHtml(d.phone)}</td><td>${escapeHtml(d.schedule || "—")}</td><td><button class="table-action danger" data-delete="doctors" data-id="${d._id}">Delete</button></td></tr>`).join("") : '<tr><td colspan="5" class="empty">No matching doctor records.</td></tr>';
}
function renderAppointments() {
  const rows = state.appointments.filter(a => matches($("#appointment-search").value, [a.patientName,a.doctorName,a.date,a.reason,a.status]));
  $("#appointments-table").innerHTML = rows.length ? rows.map(a => `<tr><td><strong>${escapeHtml(a.patientName)}</strong></td><td>${escapeHtml(a.doctorName)}</td><td>${formatDate(a.date)}</td><td>${escapeHtml(a.time)}</td><td>${escapeHtml(a.reason || "—")}</td><td><span class="badge ${String(a.status).toLowerCase()}">${escapeHtml(a.status)}</span><br><button class="table-action success" data-status="appointments" data-id="${a._id}" data-value="Completed">Complete</button><button class="table-action danger" data-status="appointments" data-id="${a._id}" data-value="Cancelled">Cancel</button><button class="table-action danger" data-delete="appointments" data-id="${a._id}">Delete</button></td></tr>`).join("") : '<tr><td colspan="6" class="empty">No matching appointments.</td></tr>';
}
function renderBills() {
  const rows = state.bills.filter(b => matches($("#bill-search").value, [b.patientName,b.description,b.status]));
  $("#bills-table").innerHTML = rows.length ? rows.map(b => `<tr><td><strong>${escapeHtml(b.patientName)}</strong></td><td>${escapeHtml(b.description)}</td><td>${money(b.amount)}</td><td>${formatDate(String(b.createdAt || "").slice(0,10))}</td><td><span class="badge ${String(b.status).toLowerCase()}">${escapeHtml(b.status)}</span></td><td>${b.status === "Unpaid" ? `<button class="table-action success" data-status="bills" data-id="${b._id}" data-value="Paid">Mark paid</button>` : ""}<button class="table-action danger" data-delete="bills" data-id="${b._id}">Delete</button></td></tr>`).join("") : '<tr><td colspan="6" class="empty">No matching billing records.</td></tr>';
}
function renderDashboard() {
  $("#patient-count").textContent = state.patients.length;
  $("#doctor-count").textContent = state.doctors.length;
  $("#appointment-count").textContent = state.appointments.length;
  $("#unpaid-total").textContent = money(state.bills.filter(b => b.status === "Unpaid").reduce((sum,b) => sum + Number(b.amount || 0), 0));
  const recent = [...state.appointments].sort((a,b) => `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`)).slice(0,5);
  $("#recent-appointments").innerHTML = recent.length ? recent.map(a => `<tr><td><strong>${escapeHtml(a.patientName)}</strong></td><td>${escapeHtml(a.doctorName)}</td><td>${formatDate(a.date)}</td><td>${escapeHtml(a.time)}</td><td><span class="badge ${String(a.status).toLowerCase()}">${escapeHtml(a.status)}</span></td></tr>`).join("") : '<tr><td colspan="5" class="empty">No appointments yet. Add one to get started.</td></tr>';
}
async function loadSection(view) {
  const key = view === "billing" ? "bills" : view;
  try {
    state[key] = await api(key);
    if (view === "patients") renderPatients();
    if (view === "doctors") renderDoctors();
    if (view === "appointments") renderAppointments();
    if (view === "billing") renderBills();
    renderDashboard();
  } catch (err) {
    toast(`${err.message}. Configure MongoDB in .env and restart the server.`);
  }
}
async function loadAll() {
  for (const key of ["patients","doctors","appointments","bills"]) {
    try { state[key] = await api(key); } catch (_err) { state[key] = []; }
  }
  renderDashboard();
}
function formData(form) {
  return Object.fromEntries(new FormData(form).entries());
}
async function submitForm(formId, endpoint, section) {
  const form = $(`#${formId}`);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const payload = formData(form);
    if (payload.age !== undefined) payload.age = Number(payload.age);
    if (payload.amount !== undefined) payload.amount = Number(payload.amount);
    try {
      await api(endpoint, { method: "POST", body: JSON.stringify(payload) });
      form.reset();
      form.classList.add("hidden");
      toast("Saved successfully!");
      await loadSection(section);
    } catch (err) { toast(err.message); }
  });
}
async function handleTableAction(event) {
  const del = event.target.closest("[data-delete]");
  const status = event.target.closest("[data-status]");
  if (del) {
    if (!confirm("Are you sure you want to delete this record?")) return;
    try {
      await api(`${del.dataset.delete}/${del.dataset.id}`, { method: "DELETE" });
      toast("Record deleted.");
      await loadSection(del.dataset.delete === "bills" ? "billing" : del.dataset.delete);
    } catch (err) { toast(err.message); }
  }
  if (status) {
    try {
      await api(`${status.dataset.status}/${status.dataset.id}`, { method: "PATCH", body: JSON.stringify({ status: status.dataset.value }) });
      toast("Status updated.");
      await loadSection(status.dataset.status === "bills" ? "billing" : "appointments");
    } catch (err) { toast(err.message); }
  }
}
$$(".nav-link").forEach(btn => btn.addEventListener("click", () => showView(btn.dataset.view)));
$$("[data-open]").forEach(btn => btn.addEventListener("click", () => showView(btn.dataset.open)));
$("#show-patient-form").addEventListener("click", () => showForm("patient"));
$("#show-doctor-form").addEventListener("click", () => showForm("doctor"));
$("#show-appointment-form").addEventListener("click", () => showForm("appointment"));
$("#show-bill-form").addEventListener("click", () => showForm("bill"));
$$(".cancel-form").forEach(btn => btn.addEventListener("click", () => btn.closest("form").classList.add("hidden")));
["patients","doctors","appointments","bills"].forEach(key => $(`#${key}-table`).addEventListener("click", handleTableAction));
bindSearch("#patient-search", renderPatients);
bindSearch("#doctor-search", renderDoctors);
bindSearch("#appointment-search", renderAppointments);
bindSearch("#bill-search", renderBills);
submitForm("patient-form", "patients", "patients");
submitForm("doctor-form", "doctors", "doctors");
submitForm("appointment-form", "appointments", "appointments");
submitForm("bill-form", "bills", "billing");
loadAll();
