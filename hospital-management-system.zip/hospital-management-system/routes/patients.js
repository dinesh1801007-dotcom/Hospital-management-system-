const router = require("express").Router();
const Patient = require("../models/Patient");

router.get("/", async (_req, res) => {
  try { res.json(await Patient.find().sort({ createdAt: -1 })); }
  catch (e) { res.status(500).json({ message: "Could not fetch patients. Check MongoDB connection." }); }
});
router.post("/", async (req, res) => {
  try { const item = await Patient.create(req.body); res.status(201).json(item); }
  catch (e) { res.status(400).json({ message: e.message }); }
});
router.put("/:id", async (req, res) => {
  try {
    const item = await Patient.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ message: "Patient not found" });
    res.json(item);
  } catch (e) { res.status(400).json({ message: e.message }); }
});
router.delete("/:id", async (req, res) => {
  try {
    const item = await Patient.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: "Patient not found" });
    res.json({ message: "Patient deleted" });
  } catch (e) { res.status(400).json({ message: e.message }); }
});
module.exports = router;
