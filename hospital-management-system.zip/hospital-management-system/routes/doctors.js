const router = require("express").Router();
const Doctor = require("../models/Doctor");
router.get("/", async (_req, res) => {
  try { res.json(await Doctor.find().sort({ name: 1 })); }
  catch (e) { res.status(500).json({ message: "Could not fetch doctors. Check MongoDB connection." }); }
});
router.post("/", async (req, res) => {
  try { res.status(201).json(await Doctor.create(req.body)); }
  catch (e) { res.status(400).json({ message: e.message }); }
});
router.delete("/:id", async (req, res) => {
  try {
    const item = await Doctor.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: "Doctor not found" });
    res.json({ message: "Doctor deleted" });
  } catch (e) { res.status(400).json({ message: e.message }); }
});
module.exports = router;
