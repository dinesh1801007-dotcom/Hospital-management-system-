const router = require("express").Router();
const Bill = require("../models/Bill");
router.get("/", async (_req, res) => {
  try { res.json(await Bill.find().sort({ createdAt: -1 })); }
  catch (e) { res.status(500).json({ message: "Could not fetch bills. Check MongoDB connection." }); }
});
router.post("/", async (req, res) => {
  try { res.status(201).json(await Bill.create(req.body)); }
  catch (e) { res.status(400).json({ message: e.message }); }
});
router.patch("/:id", async (req, res) => {
  try {
    const item = await Bill.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ message: "Bill not found" });
    res.json(item);
  } catch (e) { res.status(400).json({ message: e.message }); }
});
router.delete("/:id", async (req, res) => {
  try {
    const item = await Bill.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: "Bill not found" });
    res.json({ message: "Bill deleted" });
  } catch (e) { res.status(400).json({ message: e.message }); }
});
module.exports = router;
