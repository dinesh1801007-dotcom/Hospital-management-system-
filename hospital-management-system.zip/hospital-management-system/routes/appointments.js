const router = require("express").Router();
const Appointment = require("../models/Appointment");
router.get("/", async (_req, res) => {
  try { res.json(await Appointment.find().sort({ date: 1, time: 1 })); }
  catch (e) { res.status(500).json({ message: "Could not fetch appointments. Check MongoDB connection." }); }
});
router.post("/", async (req, res) => {
  try { res.status(201).json(await Appointment.create(req.body)); }
  catch (e) { res.status(400).json({ message: e.message }); }
});
router.patch("/:id", async (req, res) => {
  try {
    const item = await Appointment.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ message: "Appointment not found" });
    res.json(item);
  } catch (e) { res.status(400).json({ message: e.message }); }
});
router.delete("/:id", async (req, res) => {
  try {
    const item = await Appointment.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: "Appointment not found" });
    res.json({ message: "Appointment deleted" });
  } catch (e) { res.status(400).json({ message: e.message }); }
});
module.exports = router;
