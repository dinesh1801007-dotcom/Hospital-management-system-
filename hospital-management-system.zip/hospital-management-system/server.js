require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.use("/api/patients", require("./routes/patients"));
app.use("/api/doctors", require("./routes/doctors"));
app.use("/api/appointments", require("./routes/appointments"));
app.use("/api/bills", require("./routes/bills"));

app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "Hospital Management System" }));

async function start() {
  if (process.env.MONGODB_URI) {
    try {
      await mongoose.connect(process.env.MONGODB_URI);
      console.log("Connected to MongoDB");
    } catch (err) {
      console.error("MongoDB connection failed:", err.message);
      console.log("The dashboard will still load, but database API calls need a valid MONGODB_URI.");
    }
  } else {
    console.log("MONGODB_URI not set. Add it to .env to enable database features.");
  }
  app.listen(PORT, () => console.log(`Hospital Management System running at http://localhost:${PORT}`));
}
start();
