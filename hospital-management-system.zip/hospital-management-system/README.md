# CarePoint — Hospital Management System

A responsive full-stack Hospital Management System built for a Web Development / Full-Stack Web Development student project.

## Features

- Dashboard with patient, doctor, appointment and unpaid-bill summaries
- Patient registration, listing, search and deletion
- Doctor directory with specializations and schedules
- Appointment booking, status updates and deletion
- Billing records, payment status updates and deletion
- Responsive layout for desktop and mobile
- REST API built with Express and MongoDB/Mongoose

## Technology stack

- Frontend: HTML, CSS, JavaScript
- Backend: Node.js and Express.js
- Database: MongoDB with Mongoose
- Version control: Git and GitHub

## Run locally

1. Install a current LTS version of Node.js.
2. Install and configure MongoDB locally or create a MongoDB Atlas database.
3. Open a terminal in this project folder and run:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env` and set `MONGODB_URI` to your own MongoDB connection string.
5. Start the app:

   ```bash
   npm start
   ```

6. Open `http://localhost:3000` in your browser.

The API requires a working MongoDB connection. The page can load without it, but database actions will not work until the connection is configured.

## API endpoints

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Check server status |
| GET, POST | `/api/patients` | List or add patients |
| PUT, DELETE | `/api/patients/:id` | Update or delete a patient |
| GET, POST | `/api/doctors` | List or add doctors |
| DELETE | `/api/doctors/:id` | Delete a doctor |
| GET, POST | `/api/appointments` | List or book appointments |
| PATCH, DELETE | `/api/appointments/:id` | Update status or delete an appointment |
| GET, POST | `/api/bills` | List or create bills |
| PATCH, DELETE | `/api/bills/:id` | Update payment status or delete a bill |

## Upload to GitHub

1. Create a repository named `hospital-management-system`.
2. Upload the project files, or use Git:

   ```bash
   git init
   git add .
   git commit -m "Add Hospital Management System project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/hospital-management-system.git
   git push -u origin main
   ```

3. Replace `YOUR-USERNAME` with your GitHub username.
4. Do not commit `.env`, passwords, real patient data, or `node_modules`.

## Important note

This is an educational demo, not a production-ready clinical system. It does not include authentication, role-based access, audit logging, or production security controls. Use only fictional data for demonstrations. Do not store real patient information in this student project.
